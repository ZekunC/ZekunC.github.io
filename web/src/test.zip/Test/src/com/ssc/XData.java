package com.ssc;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/XData")
public class XData extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public XData() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub	
		request.setCharacterEncoding("UTF-8");
		String action = request.getParameter("action");
		String data="";
		switch(action) {
			case "doLogin":data=doLogin(request);break;
			case "getLogs":data=getLogs();break;
			case "xdelete":data=xdelete(request);break;
		}		
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.getWriter().println(data);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	protected String getLogs() {
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			String url="jdbc:sqlserver://localhost:59981;databaseName=NengBoHui";
			String user="Fisher";
			String password="WWWwww123456";
			Connection conn=DriverManager.getConnection( url,user,password);
			Statement stmt = conn.createStatement();
			String sql="select top 10 * from Logs";
			ResultSet rs = stmt.executeQuery(sql);
			StringBuilder sb=new StringBuilder();
			sb.append("[");
			while(rs.next()){
	                // ͨ���ֶμ���
	                String id  = rs.getObject("Id").toString();
	                String name = rs.getString("Name");
	                String ip = rs.getString("IP");
	                sb.append("{\"Id\":\""+id+"\",\"Name\":\""+name+"\"},");
	                System.out.println(id);
	        }
            rs.close();
            stmt.close();
            conn.close();			
			sb.deleteCharAt(sb.length()-1);
			sb.append("]");
	        return sb.toString();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "";
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "";
		}
	}
	protected String xdelete(HttpServletRequest request) {
		try {
			String Id=request.getParameter("Id");
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			String url="jdbc:sqlserver://localhost:59981;databaseName=NengBoHui";
			String user="Fisher";
			String password="WWWwww123456";
			Connection conn=DriverManager.getConnection( url,user,password);
			Statement stmt = conn.createStatement();
			String sql="delete from Logs where Id='"+Id+"'";
			stmt.execute(sql);		
            
            stmt.close();
            conn.close();			
			
	        return "{\"rlt\":\"0\"}";
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "{\"rlt\":\"1\"}";
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "{\"rlt\":\"1\"}";
		}
	}
	protected String doLogin(HttpServletRequest request) {
		String usr=request.getParameter("UserName");
		String pwd=request.getParameter("Password");
		if(usr.trim()!=""&&pwd.trim()!="") {
			try {
				Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
				String url="jdbc:sqlserver://localhost:59981;databaseName=NengBoHui";
				String user="Fisher";
				String password="WWWwww123456";
				Connection conn=DriverManager.getConnection( url,user,password);
				Statement stmt = conn.createStatement();
				String sql="select top 1 * from Users where UserName='"
				+usr+"' and Password='"+pwd+"'";
				ResultSet rs = stmt.executeQuery(sql);
				String Id="";
				String UserName="";
				
				while(rs.next()){
		                // ͨ���ֶμ���
		                Id  = rs.getObject("Id").toString();
		                UserName = rs.getString("UserName");		               
				}
	            rs.close();
	            stmt.close();
	            conn.close();			
				if(UserName!=""&&Id!="") {
					HttpSession session = request.getSession();//û��Session���½�һ�� 
					session.setAttribute("UserName",UserName);//�ڷ������˴洢"��-ֵ��" 
					return "{\"rlt\":\"0\"}";
				}else {
					return "{\"rlt\":\"1\"}";
				}
		        
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return "{\"rlt\":\"1\"}";
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return "{\"rlt\":\"1\"}";
			}
		}else {
			return "{\"rlt\":\"1\"}";
		}
	}
}
