package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.*;
/**
 * Servlet implementation class XData
 */
@WebServlet("/XData")
public class XData extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public XData() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		String action = request.getParameter("action");
		String data="";
		switch(action) {
			case "doLogin":data=doLogin(request);break;
	     	case "getLogs":data=getLogs();break;         //ע�͵�
		//	case "xdelete":data=xdelete(request);break;  //ע�͵�
		}		
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.getWriter().println(data);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	protected String doLogin(HttpServletRequest request) {
		String usr=request.getParameter("UserName");
		String pwd=request.getParameter("Password");
		if(usr.trim()!=""&&pwd.trim()!="") {
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				String url="jdbc:oracle:thin:@127.0.0.1:1521:orcl";
				String user="scott";
				String password="tiger";  //������������룬��һ����tiger
				Connection conn=DriverManager.getConnection( url,user,password);
				Statement stmt = conn.createStatement();
				String sql="select  * from Users where UserName='"
				+usr+"' and Password='"+pwd+"'";
				ResultSet rs = stmt.executeQuery(sql);
				String Id="";
				String UserName="";
				
				while(rs.next()){
		                // ͨ���ֶμ���
		                Id  = rs.getObject("Id").toString();
		                UserName = rs.getString("UserName");		               
				}
	            rs.close();
	            stmt.close();
	            conn.close();			
				if(UserName!=""&&Id!="") {
					HttpSession session = request.getSession();//û��Session���½�һ�� 
					session.setAttribute("UserName",UserName);//�ڷ������˴洢"��-ֵ��" 
					return "{\"rlt\":\"0\"}";
				}else {
					return "{\"rlt\":\"1\"}";
				}
		        
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return "{\"rlt\":\"1\"}";
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return "{\"rlt\":\"1\"}";
			}
		}else {
			return "{\"rlt\":\"1\"}";
		}
	}
	protected String getLogs() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url="jdbc:oracle:thin:@127.0.0.1:1521:orcl";
			String user="scott";
			String password="tiger";  //������������룬��һ����tiger
			Connection conn=DriverManager.getConnection( url,user,password);
			Statement stmt = conn.createStatement();
			String sql="select  * from EMP";
			ResultSet rs = stmt.executeQuery(sql);
			StringBuilder sb=new StringBuilder();
			sb.append("[");
			while(rs.next()){
	                // ͨ���ֶμ���
	                int id  = rs.getInt("EMPNO");
	                String name = rs.getString("ENAME");
	                sb.append("{\"Id\":\""+id+"\",\"Name\":\""+name+"\"},");
	                System.out.println(id);
	        }
            rs.close();
            stmt.close();
            conn.close();			
			sb.deleteCharAt(sb.length()-1);
			sb.append("]");
	        return sb.toString();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "";
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "";
		}
	}

}
